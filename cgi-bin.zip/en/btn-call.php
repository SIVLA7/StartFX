<section class="section callto-action-area section-grey">
    <div class="container">
        <div class="row">
            <div class="callto-action col-xl-8 col-md-12 col-sm-12">
                <div class="callto-action-inner text-uppercase align-items-center">
                    <div class="col-lg-6 col-md-7 col-sm-5">
                        <h2>Market is calling</h2>
                    </div>
                    <div class="col-lg-6 col-md-5 col-sm-7">
                        <div class="btn-wrapper btn-callto-wrapper">
                            <a href="https://my.startfx.com/en-us/signup.aspx" class="btn market-btn btn-lg cover-btn text-uppercase">
                                <span>Start trading now</span>
                            </a>
                            <span class="txt-demo txt-demo-md callto-txt-demo">Free demo included</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
