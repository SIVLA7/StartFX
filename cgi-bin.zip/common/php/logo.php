<div class="logo">
   <a class="header-logo" href="index.php">
     <img class="img-logo" src="../common/images/logo/logo_startfx.png">
   </a>
   <a class="header-sticky-logo" href="index.php">
     <img class="img-logo" src="../common/images/logo/sticky_logo.png">
   </a>
</div>
