<a class="mobile-logo" href="index.php">
  <img src="../common/images/logo/logo_startfx.png" alt="mobile logo">
</a>
<a class="mobile-logo-sticky" href="index.php">
  <img src="../common/images/logo/sticky_logo.png" alt="mobile logo">
</a>
<a class="mobile-logo-dropdown" href="index.php">
  <img src="../common/images/logo/logo_compresed.png" alt="mobile logo">
</a>
