<section class="section callto-action-area section-grey">
    <div class="container">
        <div class="row">
            <div class="callto-action col-xl-10 сol-lg-10 col-md-12 col-12">
                <div class="callto-action-inner align-items-center">
                    <div class="col-lg-6 col-md-5">
                        <h2>СДЕЛАЙ ШАГ К УСПЕХУ</h2>
                    </div>
                    <div class="col-lg-5 col-md-7">
                        <div class="btn-wrapper btn-callto-wrapper">
                            <a href="https://my.startfx.com/ru-ru/signup.aspx" class="btn market-btn btn-lg cover-btn text-uppercase">
                                <span>Начните торговлю сейчас</span>
                            </a>
                            <span class="txt-demo txt-demo-sm callto-txt-demo">БЕСПЛАТНЫЙ демо-счет включен</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
